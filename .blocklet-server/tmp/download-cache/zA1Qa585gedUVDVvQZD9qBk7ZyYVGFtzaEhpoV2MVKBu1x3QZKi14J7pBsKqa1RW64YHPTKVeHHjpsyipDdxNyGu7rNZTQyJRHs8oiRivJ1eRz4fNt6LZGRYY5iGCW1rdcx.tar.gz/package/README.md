# Coming Soon page

A simple coming soon page implementation.
